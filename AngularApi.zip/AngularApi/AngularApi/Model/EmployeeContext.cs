﻿using AngularApi.Model;
using Microsoft.EntityFrameworkCore;

namespace AngularApi.Model
{
    public class EmployeeContext : DbContext
    {
        public EmployeeContext(DbContextOptions<EmployeeContext> options) : base(options)
        {

        }
        public DbSet<TblEmployee> TblEmployees { get; set; }
        public DbSet<TblDesignation> TblDesignations { get; set; }

    }
}
